const config = {
    type: Phaser.AUTO,
    width: 800,
    height: 600,
    scene: {
        preload: preload,
        create: create,
        update: update
    },
    // añadimos la propiedad "physics" al objeto config
    physics: {
        default: 'arcade',
        arcade: {
            gravity: { y: 300 },
            //debug: true
        }
    },
};

const game = new Phaser.Game(config);

function preload() {
    this.load.image('sky', 'assets/sky.png');
    // el suelo es una imagen de 400x32 px
    this.load.image('ground', 'assets/platform.png');
    this.load.image('star', 'assets/star.png');
    this.load.image('bomb', 'assets/bomb.png');
    this.load.spritesheet('dude',
        'assets/dude.png', { frameWidth: 32, frameHeight: 48 }
    );
}

let counter = 0;

let platforms;

function collectStar(player, star) {
    star.disableBody(true, true);
    counter += 5;

    var el = document.getElementById("counter");
    el.innerHTML = counter;
    console.log('Estrella!!!');
}

function hitBomb(player, bomb) {
    bomb.disableBody(true, true);
    counter -= 15;

}

function create() {
    this.add.image(400, 300, 'sky');

    platforms = this.physics.add.staticGroup();

    platforms.create(400, 568, 'ground').setScale(2).refreshBody();
    // añadimos la plataforma de más abajo, duplicamos sus dimensiones y actualizamos.
    // luego añadimos otras plataformas en pantalla
    platforms.create(600, 400, 'ground');
    platforms.create(50, 250, 'ground');
    platforms.create(750, 220, 'ground');

    // agrego al player
    player = this.physics.add.sprite(100, 450, 'dude');

    player.setBounce(0.2);
    player.setCollideWorldBounds(true);

    this.anims.create({
        key: 'left',
        frames: this.anims.generateFrameNumbers('dude', { start: 0, end: 3 }),
        frameRate: 10,
        repeat: -1
    });

    this.anims.create({
        key: 'turn',
        frames: [{ key: 'dude', frame: 4 }],
        frameRate: 20
    });

    this.anims.create({
        key: 'right',
        frames: this.anims.generateFrameNumbers('dude', { start: 5, end: 8 }),
        frameRate: 10,
        repeat: -1
    });

    this.physics.add.collider(player, platforms);

    stars = this.physics.add.group({
        key: 'star',
        repeat: 8,
        setXY: {
            x: 12,
            y: 0,
            stepX: 80
        }
    });

    // agrego la bomba
    bomb = this.physics.add.sprite(10, 0, 'bomb');
    bomb.setBounce(1);
    bomb.setVelocity(100, 20);
    bomb.setCollideWorldBounds(true);

    this.physics.add.collider(bomb, platforms);
    // evitamos que traspase las plataformas
    this.physics.add.collider(stars, platforms);
    // detectar la colisión entre el pesonaje y la estrella:
    this.physics.add.overlap(player, stars, collectStar, null, this);
    // detectar la colisión entre el pesonaje y la bomba:
    this.physics.add.overlap(player, bomb, hitBomb, null, this);
    //añado funcion click al boton restart
    var el = document.getElementById("button");
    let context = this;
    el.onclick = function() {
        context.scene.stop();
        context.scene.start();
    }
}



function update() {
    const cursors = this.input.keyboard.createCursorKeys();

    if (cursors.left.isDown) {
        player.setVelocityX(-160);

        player.anims.play('left', true);
    } else if (cursors.right.isDown) {
        player.setVelocityX(160);

        player.anims.play('right', true);
    } else {
        player.setVelocityX(0);

        player.anims.play('turn');
    }

    if (cursors.up.isDown && player.body.touching.down) {
        player.setVelocityY(-330);
    }
}